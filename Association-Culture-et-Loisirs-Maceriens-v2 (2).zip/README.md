# Association Culture et Loisirs Macériens

Site vitrine de l'association.

## Modifier le site
Le fichier principal est `index.html`.
Sur GitHub : ouvrir `index.html` → bouton crayon ✏️ → modifier → **Commit changes**.

Les sections principales sont :
- Accueil
- Présentation
- Activités
- Événements et actualités
- Contact
